﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a=0;

            Console.WriteLine("Digite um valor");
            a = double.Parse(Console.ReadLine());

            do
            { 
                Console.WriteLine("Digite um valor novamente");
                a = double.Parse(Console.ReadLine());

            } 
            while(a <= 0);
        }
    }
}
