﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a=0;
            double b =0;

            Console.WriteLine("Digite o primeiro valor");
                a=double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o segundo valor");
            b = double.Parse(Console.ReadLine());
            do
            {
                Console.WriteLine("digite novamenteo segundo valor");
                b = double.Parse(Console.ReadLine());
            }
            while (b < a);
        }
    }
}
