﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char sex;

            do
            {
                Console.WriteLine("Digite o Sexo (M ou F)");
                sex = char.Parse(Console.ReadLine());
            
            } 
            while (sex != 'F' && sex != 'M' && sex != 'f' && sex != 'm');
        }
    }
}
