﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cont = 0;
            double valor = 0;
            double result = 0;

            Console.WriteLine("Digite o a ser calculado");
            valor=double.Parse(Console.ReadLine());


            do
            {
                cont = cont + 1;

                result = valor * cont;

                Console.WriteLine("{0} * {1} = {2}", valor, cont, result);

            } while (cont < 10);
        }
    }
}
